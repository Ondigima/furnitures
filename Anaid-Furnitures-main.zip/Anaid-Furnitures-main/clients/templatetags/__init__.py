# from .filters import rating_stars
# from django.template import Library
# register=Library()

# register.filter('rating_stars', rating_stars)